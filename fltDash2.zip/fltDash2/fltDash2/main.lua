---------------------------------------------------------------------------
-- FlightDash Widget For Limited Telemetry
-- EdgeTX 2.11+
-- RAM-only min/max
---------------------------------------------------------------------------

local name = "fltDash2"

---------------------------------------------------------------------------
-- OPTIONS
---------------------------------------------------------------------------

local options = {
  { "Arm",       SOURCE, 0 },
  { "Motor",     SOURCE, 0 },
  { "Rx Signal", SOURCE, 0 },
  { "Rx Qty",    SOURCE, 0 },
  { "Rpm",       SOURCE, 0 },
  { "GV",        SOURCE, 0 },
  { "Thr",        SOURCE, 0 },
}

---------------------------------------------------------------------------
-- MIN / MAX STATE (RAM ONLY)
---------------------------------------------------------------------------

local stats = {
  RPM  = { min = nil, max = nil },
  RSS  = { min = nil, max = nil },
  RQTY = { min = nil, max = nil },
}

---------------------------------------------------------------------------
-- CREATE / UPDATE
---------------------------------------------------------------------------

local function create(zone, opts)
  return { zone = zone, options = opts or {} }
end

local function update(widget, opts)
  widget.options = opts
end

local function sourceLabel(src, fallback)
  if src ~= 0 then
    local info = getSourceInfo(src)
    if info and info.name then
      return info.name
    end
  end
  return fallback
end

--Standard EdgeTx Colours
--BLACK
--WHITE
--GREEN
--DARKGREEN
--YELLOW
--RED
--DARKRED
--GREY
--DARKGREY
--BLUE
--ORANGE

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)
  local z   = widget.zone
  local opt = widget.options

  lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, COLOR_BLACK)

local PURPLE = lcd.RGB(149, 66, 245)
local BROWN = lcd.RGB(79, 54, 39)
local PINK = lcd.RGB(206, 126, 252)
local CYAN = lcd.RGB(58, 242, 242)
local LIGHTBLUE = lcd.RGB(25, 175, 255)


  -------------------------------------------------------------------------
  -- STATES
  -------------------------------------------------------------------------

  local armOn   = opt.Arm   ~= 0 and getValue(opt.Arm)   > 0
  local motorOn = opt.Motor ~= 0 and getValue(opt.Motor) > 0
  local rssVal  = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0
  local rqtyVal = (opt["Rx Qty"] ~= 0 and getValue(opt["Rx Qty"])) or 0
  local rpmVal  = (opt.Rpm ~= 0 and getValue(opt.Rpm)) or 0
  local thrVal  = (opt.Thr ~= 0 and getValue(opt.Thr)) or 0

  -------------------------------------------------------------------------
  -- UPDATE MIN / MAX (only when telemetry valid)
  -------------------------------------------------------------------------

  if rssVal ~= 0 then
    if stats.RSS.min == nil or rssVal < stats.RSS.min then stats.RSS.min = rssVal end
    if stats.RSS.max == nil or rssVal > stats.RSS.max then stats.RSS.max = rssVal end
  end

  if rqtyVal ~= 0 then
    if stats.RQTY.min == nil or rqtyVal < stats.RQTY.min then stats.RQTY.min = rqtyVal end
    if stats.RQTY.max == nil or rqtyVal > stats.RQTY.max then stats.RQTY.max = rqtyVal end
  end

  if rpmVal ~= 0 then
    if stats.RPM.max == nil or rpmVal > stats.RPM.max then stats.RPM.max = rpmVal end
  end

  -------------------------------------------------------------------------
  -- HEADER
  -------------------------------------------------------------------------
local nameColor
if armOn and rssVal ~= 0 then
  nameColor = RED
elseif rssVal ~= 0 then
  nameColor = GREEN
else
  nameColor = WHITE
end

  lcd.drawText(
    z.x + z.w - 55,
    z.y + 6,
    model.getInfo().name or "MODEL",
    RIGHT + DBLSIZE + nameColor
  )

  local dt = getDateTime()
  local months = { "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec" }

  lcd.drawText(z.x + z.w - 10, z.y + 8,
    string.format("%d %s", dt.day, months[dt.mon]),
    RIGHT + SMLSIZE + WHITE)

  lcd.drawText(z.x + z.w - 10, z.y + 22,
    string.format("%02d:%02d", dt.hour, dt.min),
    RIGHT + SMLSIZE + WHITE)

  -------------------------------------------------------------------------
  -- TX BATTERY
  -------------------------------------------------------------------------

  local battX, battY, battW, battH = z.x + 65, z.y + 12, 96, 32
  local txV = getValue("tx-voltage") or 0
  local pct = math.max(0, math.min(1, (txV - 6.8) / (8.4 - 6.8)))

  local battColor = (txV < 7.1) and RED or (txV <= 7.5 and YELLOW or GREEN)

  lcd.drawRectangle(battX, battY, battW, battH, WHITE)
  lcd.drawFilledRectangle(battX + battW, battY + battH / 4, 6, battH / 2, WHITE)
  lcd.drawFilledRectangle(battX + 1, battY + 1, (battW - 2) * pct, battH - 2, battColor)

  lcd.drawText(
    battX + battW / 2,
    battY + battH / 2 - 10,
    string.format("%.1fV", txV),
    CENTER + WHITE + BOLD
  )

  if opt.GV ~= 0 then
    lcd.drawText(
      battX + battW + 30,
      battY + battH / 2 - 15,
      string.format("%d", getValue(opt.GV) or 0),
      LEFT + SMLSIZE + WHITE + BOLD
    )
  end

  local sepY = battY + battH + 6
  lcd.drawFilledRectangle(battX, sepY, z.w - battX - 10, 2, GREY)

  -------------------------------------------------------------------------
  -- CIRCULAR LAYOUT
  -------------------------------------------------------------------------

  local centerY = sepY + 90
  local rBig, rMed, spacing = 83, 60, -15

  local totalW = rBig*2 + rMed*4 + spacing*2
  local startX = z.x + (z.w - totalW) / 2 - 45

  local rpmCX  = startX + rBig
  local rssCX  = rpmCX + rBig + spacing + rMed
  local rqtyCX = rssCX + rMed + spacing + rMed

  lcd.drawFilledCircle(rqtyCX, centerY, rMed, GREY)
  lcd.drawCircle(rqtyCX, centerY, rMed, RED)
  lcd.drawCircle(rqtyCX, centerY, rMed, RED)
  lcd.drawFilledCircle(rssCX,  centerY, rMed, GREY)
  lcd.drawCircle(rssCX, centerY, rMed, RED)
  lcd.drawCircle(rssCX, centerY, rMed, RED)
  lcd.drawFilledCircle(rpmCX,  centerY, rBig, GREY)
  lcd.drawCircle(rpmCX, centerY, rBig, RED)
  lcd.drawCircle(rpmCX, centerY, rBig, RED)

---------------------------------------------------------------------------
-- RPM GAUGE (NEEDLE + SCALE + MAX)
---------------------------------------------------------------------------

local rpmMax = 3400
local radius = rBig - 6

-- draw top semicircle arc (ticks + numbers)
local steps = {0,565,1135,1700,2270,2835,3400}

for i = 1, #steps do
  local val = steps[i]

  -- map 0→3400 to 180°→0°
  local angle = math.rad(180 - (val / rpmMax) * 180)

  local tickLen = 6

  local x1 = rpmCX + math.cos(angle) * (radius - tickLen/2)
  local y1 = centerY - math.sin(angle) * (radius - tickLen/2)

  local x2 = rpmCX + math.cos(angle) * (radius + tickLen/2)
  local y2 = centerY - math.sin(angle) * (radius + tickLen/2)


  -- Ticks
  lcd.drawLine(x1, y1, x2, y2, SOLID)


  -- Numbers inside circle
  local tx = rpmCX + math.cos(angle) * (radius - 11)
  local ty = centerY - math.sin(angle) * (radius - 11) - 8

  lcd.drawText(tx, ty, tostring(math.floor(val / 100 + 0.5)), CENTER + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))



end

---------------------------------------------------------------------------
-- RPM NEEDLE
---------------------------------------------------------------------------

-- Throttle % drawn before needle
lcd.drawText(rpmCX, centerY - 25,
  string.format("%d%%", thrVal),
  CENTER + SMLSIZE + ((rssVal ~= 0) and YELLOW or GREY)
)

local rpmClamped = math.max(0, math.min(rpmMax, rpmVal))
local angle = math.rad(180 - (rpmClamped / rpmMax) * 180)

local needleLen = radius - 25

-- floor to integers
local nx = math.floor(rpmCX + math.cos(angle) * needleLen + 0.5)
local ny = math.floor(centerY - math.sin(angle) * needleLen + 0.5)

-- thicker needle
for o = -3, 3 do
  lcd.drawLine(rpmCX + o, centerY, nx + o, ny, SOLID)
end

-- hub
lcd.drawFilledCircle(rpmCX, centerY, 4, BLACK)
lcd.drawFilledCircle(rpmCX, centerY, 2, WHITE)


---------------------------------------------------------------------------
-- RPM TEXT
---------------------------------------------------------------------------

lcd.drawText(rpmCX, centerY + 5,
  string.format("%d", rpmVal),
  CENTER + MIDSIZE + BOLD + ((rssVal ~= 0) and GREEN or WHITE)
)

lcd.drawText(rpmCX, centerY + 40,
  "x100 RPM",
  CENTER + SMLSIZE + WHITE)

if stats.RPM.max then
  lcd.drawText(rpmCX, centerY + 55,
    string.format("%d", stats.RPM.max),
    CENTER + SMLSIZE + WHITE)
end


  -------------------------------------------------------------------------
  -- RSS (SPEEDOMETER + VALUE + MIN / MAX)
  -------------------------------------------------------------------------

  local rssColor = WHITE
  if rssVal <= -85 then
    rssColor = RED
  elseif rssVal <= -70 then
    rssColor = YELLOW
  elseif rssVal < 0 then
    rssColor = GREEN
  end


  -------------------------------------------------------------------------
  -- RSS SPEEDOMETER SCALE (0 → -100 across ~110°)
  -------------------------------------------------------------------------

  local rssMin = -100
  local rssMax = 0
  local sweepDeg = 125
  local radius = rMed - 6

  local steps = {0, -25, -50, -75, -100}

  for i = 1, #steps do
    local val = steps[i]

    -- map 0→-100 to 0→110 degrees (clockwise from right side)
    local pct = math.abs(val) / 100
    local angle = math.rad(0 + pct * sweepDeg)

    local tickLen = 5

    local x1 = rssCX + math.cos(angle) * (radius - tickLen/2)
    local y1 = centerY - math.sin(angle) * (radius - tickLen/2)

    local x2 = rssCX + math.cos(angle) * (radius + tickLen/2)
    local y2 = centerY - math.sin(angle) * (radius + tickLen/2)

    lcd.drawLine(x1, y1, x2, y2, SOLID)

    -- numbers inside circle
    local tx = rssCX + math.cos(angle) * (radius - 12)
    local ty = centerY - math.sin(angle) * (radius - 12) - 6

    lcd.drawText(tx, ty, tostring(val), CENTER + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))
 
  end


  -------------------------------------------------------------------------
  -- RSS NEEDLE
  -------------------------------------------------------------------------

  local rssClamped = math.max(rssMin, math.min(rssMax, rssVal))
  local pct = math.abs(rssClamped) / 100
  local angle = math.rad(0 + pct * sweepDeg)

  local needleLen = radius - 16

  local nx = math.floor(rssCX + math.cos(angle) * needleLen + 0.5)
  local ny = math.floor(centerY - math.sin(angle) * needleLen + 0.5)

  for o = -2, 2 do
    lcd.drawLine(rssCX + o, centerY, nx + o, ny, SOLID)
  end

  lcd.drawFilledCircle(rssCX, centerY, 3, BLACK)
  lcd.drawFilledCircle(rssCX, centerY, 1, WHITE)


  -------------------------------------------------------------------------
  -- RSS VALUE / LABEL / MINMAX (unchanged)
  -------------------------------------------------------------------------

  lcd.drawText(rssCX, centerY + 5, string.format("%ddB", rssVal),
      CENTER + MIDSIZE + rssColor + BOLD)

  lcd.drawText(rssCX, centerY + 40, sourceLabel(opt["Rx Signal"], "1RSS"),
      CENTER + SMLSIZE + WHITE)

  if stats.RSS.min and stats.RSS.max then
    lcd.drawText(rssCX, centerY + 65,
      string.format("%d / %d", stats.RSS.min, stats.RSS.max),
      CENTER + SMLSIZE + WHITE)
  end

  -------------------------------------------------------------------------
  -- RQTY (SPEEDOMETER + VALUE + MIN / MAX)
  -------------------------------------------------------------------------

  local rqtyColor = WHITE
  if rqtyVal < 1 then
    rqtyColor = WHITE
  elseif rqtyVal <= 69 then
    rqtyColor = RED
  elseif rqtyVal <= 89 then
    rqtyColor = YELLOW
  elseif rqtyVal <= 100 then
    rqtyColor = GREEN
  end


  -------------------------------------------------------------------------
  -- RQTY SPEEDOMETER SCALE (0 → 100 across 125°)
  -------------------------------------------------------------------------

  local rqtyMin = 0
  local rqtyMax = 100
  local sweepDeg = 125
  local radius = rMed - 6

  local steps = {0, 25, 50, 75, 100}

  for i = 1, #steps do
    local val = steps[i]

    -- map 0→100 to 0→125 degrees (clockwise from right side)
    local pct = val / 100
    local angle = math.rad(0 + pct * sweepDeg)

    local tickLen = 5

    local x1 = rqtyCX + math.cos(angle) * (radius - tickLen/2)
    local y1 = centerY - math.sin(angle) * (radius - tickLen/2)

    local x2 = rqtyCX + math.cos(angle) * (radius + tickLen/2)
    local y2 = centerY - math.sin(angle) * (radius + tickLen/2)

    lcd.drawLine(x1, y1, x2, y2, SOLID)

    -- numbers inside circle
    local tx = rqtyCX + math.cos(angle) * (radius - 12)
    local ty = centerY - math.sin(angle) * (radius - 12) - 6

    lcd.drawText(tx, ty, tostring(val), CENTER + SMLSIZE + ((rssVal ~= 0) and YELLOW or WHITE))
  
  end


  -------------------------------------------------------------------------
  -- RQTY NEEDLE
  -------------------------------------------------------------------------

  local rqtyClamped = math.max(rqtyMin, math.min(rqtyMax, rqtyVal))
  local pct = rqtyClamped / 100
  local angle = math.rad(0 + pct * sweepDeg)

  local needleLen = radius - 16

  local nx = math.floor(rqtyCX + math.cos(angle) * needleLen + 0.5)
  local ny = math.floor(centerY - math.sin(angle) * needleLen + 0.5)

  for o = -2, 2 do
    lcd.drawLine(rqtyCX + o, centerY, nx + o, ny, SOLID)
  end

  lcd.drawFilledCircle(rqtyCX, centerY, 3, BLACK)
  lcd.drawFilledCircle(rqtyCX, centerY, 1, WHITE)


  -------------------------------------------------------------------------
  -- RQLY VALUE / LABEL / MINMAX (unchanged)
  -------------------------------------------------------------------------

  lcd.drawText(rqtyCX, centerY + 5, string.format("%d%%", rqtyVal),
    CENTER + MIDSIZE + rqtyColor + BOLD)

  lcd.drawText(rqtyCX, centerY + 40, sourceLabel(opt["Rx Qty"], "RQly"),
    CENTER + SMLSIZE + WHITE)

  if stats.RQTY.min and stats.RQTY.max then
    lcd.drawText(rqtyCX, centerY + 65,
      string.format("%d / %d", stats.RQTY.min, stats.RQTY.max),
      CENTER + SMLSIZE + WHITE)
  end

 ---------------------------------------------------------------------------
 -- TIMER (VARIABLES)
 ---------------------------------------------------------------------------

 local timer = model.getTimer(0)
 local timeLeft = timer.value or 0
 local maxTime  = timer.start or 1
 local tPct = math.max(0, math.min(1, timeLeft / maxTime))

 -------------------------------------------------------------------------
 -- VERTICAL TIMER BAR
 -------------------------------------------------------------------------

  local barW, barH = 24, 120
  local barX = z.x + z.w - barW - 30
  local barY = centerY - barH / 2 - 10

  lcd.drawRectangle(barX, barY, barW, barH, WHITE)

  if rssVal ~= 0 then
    local barColor =
      (tPct <= 0.15) and RED or
      (tPct <= 0.50) and YELLOW or GREEN

    local fillH = math.floor(barH * tPct)
    lcd.drawFilledRectangle(
      barX + 1,
      barY + barH - fillH + 1,
      barW - 2,
      fillH - 2,
      barColor
    )
  end

  lcd.drawText(
    barX + barW / 2,
    barY + barH + 4,
    string.format("%02d:%02d", math.floor(timeLeft / 60), timeLeft % 60),
    CENTER + SMLSIZE + WHITE + BOLD
  )

---------------------------------------------------------------------------
-- STATUS TILES
---------------------------------------------------------------------------

-- Anchor status tiles below the timer
local tileThirdY = z.y + z.h - 40
local bottomTileH = 36
local statusTileH = math.floor(bottomTileH * 0.90)
local statusTextY = tileThirdY + statusTileH / 2 - 20

local motorOn = opt.Motor ~= 0 and getValue(opt.Motor) > 0
local fm      = getFlightMode() or 0

local texts = {
  motorOn and "Motor On" or "Motor Off",
  armOn and "ARMED" or "DISARMED",
  "FM" .. fm
}

-- ORIGINAL WIDTH LOGIC (middle tile wider)
local margin = 10
local gap = 8
local usableW = z.w - margin * 2 - gap * 2

local widths = {
  math.floor(usableW / 3),
  math.floor((usableW / 3) * 1.4),
}
widths[3] = usableW - widths[1] - widths[2]

local x = z.x + margin

for i = 1, 3 do
  local rssVal = (opt["Rx Signal"] ~= 0 and getValue(opt["Rx Signal"])) or 0

  if (i == 1 and motorOn and rssVal ~= 0)
     or (i == 2 and armOn and rssVal ~= 0) then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, RED)

  elseif (i == 1 and rssVal ~= 0)
      or (i == 2 and rssVal ~= 0) then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, GREEN)

  elseif i == 3 and rssVal ~= 0 and armOn then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, RED)

  elseif i == 3 and rssVal ~= 0 then
    lcd.drawFilledRectangle(x, tileThirdY, widths[i], statusTileH, GREEN)
  end

  lcd.drawRectangle(x, tileThirdY, widths[i], statusTileH, GREY)

  lcd.drawText(
    x + widths[i] / 2,
    statusTextY,
    texts[i],
    CENTER + DBLSIZE + WHITE
  )

  x = x + widths[i] + gap
end

end

---------------------------------------------------------------------------

return {
  name = name,
  create = create,
  refresh = refresh,
  update = update,
  options = options
}
