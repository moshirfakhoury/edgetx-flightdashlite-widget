Overview

FlightDash Lite is a simplified telemetry dashboard widget for EdgeTX radios such as the RadioMaster TX16S, built for models or receivers with limited telemetry. It focuses only on the most essential flight information — RPM, signal strength, battery, timer, and status — using clear gauges and color-coded indicators for fast, distraction-free readability while flying.

Features
- Large RPM speedometer with needle and throttle %
- RSS signal gauge (1RSS)
- RSS Link Quality (RQly)
- TX battery indicator
- Vertical timer progress bar
- Arm / Motor / Flight Mode status tiles
- RAM-only min/max tracking
- One global variable value can be displayed e.g. for Flight Counter
- Optimized for small screens and fast readability